/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  swcMinify: true,
  images: {
    domains: ['parsefiles.back4app.com'],
  },
  env: {
    NEXT_PUBLIC_BACKEND_URL: process.env.NEXT_PUBLIC_BACKEND_URL,
    NEXT_PUBLIC_APPLICATION_ID: process.env.NEXT_PUBLIC_APPLICATION_ID,
    NEXT_PUBLIC_JAVASCRIPT_KEY: process.env.NEXT_PUBLIC_JAVASCRIPT_KEY,
  },
}

module.exports = nextConfig